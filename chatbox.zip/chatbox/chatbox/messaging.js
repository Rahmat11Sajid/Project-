function onPlayAudio() {
  const img = document.getElementById("message_img");
  img.src = "a.gif";
  
}

function onPauseAudio() {
  const img = document.getElementById("message_img");
  img.src = "robot.gif";
}
